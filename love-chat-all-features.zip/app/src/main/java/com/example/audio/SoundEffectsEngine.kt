package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

/**
 * Procedural Real-time Audio Synthesizer Engine for Love Chat & BolChat.
 * Generates realistic applause, cheers, fanfare, party horn, laughter,
 * and ambient musical beats using pure PCM synthesis through AudioTrack.
 */
class SoundEffectsEngine {

    private val sampleRate = 44100
    private val scope = CoroutineScope(Dispatchers.Default)
    private var ambientTrackJob: Job? = null
    private var isPlayingAmbient = false

    fun playSoundEffect(type: SoundEffectType) {
        scope.launch {
            when (type) {
                SoundEffectType.APPLAUSE -> playApplause()
                SoundEffectType.CHEERS -> playCheers()
                SoundEffectType.FANFARE -> playFanfare()
                SoundEffectType.PARTY_HORN -> playPartyHorn()
                SoundEffectType.LAUGHTER -> playLaughter()
                SoundEffectType.GIFT_MAGIC -> playGiftMagic()
                SoundEffectType.MIC_CLICK -> playMicClick()
                SoundEffectType.HEART_BEAT -> playHeartBeat()
            }
        }
    }

    fun toggleAmbientTrack(trackType: AmbientMusicType, onStateChanged: (Boolean) -> Unit) {
        if (isPlayingAmbient) {
            stopAmbientTrack()
            onStateChanged(false)
        } else {
            startAmbientTrack(trackType)
            onStateChanged(true)
        }
    }

    fun stopAmbientTrack() {
        isPlayingAmbient = false
        ambientTrackJob?.cancel()
        ambientTrackJob = null
    }

    private fun startAmbientTrack(trackType: AmbientMusicType) {
        isPlayingAmbient = true
        ambientTrackJob = scope.launch {
            val chords = when (trackType) {
                AmbientMusicType.ROMANTIC_LOFI -> listOf(
                    listOf(261.63, 329.63, 392.00, 493.88), // Cmaj7
                    listOf(220.00, 261.63, 329.63, 392.00), // Am7
                    listOf(174.61, 220.00, 261.63, 329.63), // Fmaj7
                    listOf(196.00, 246.94, 293.66, 349.23)  // G7
                )
                AmbientMusicType.RAGA_FUSION -> listOf(
                    listOf(146.83, 220.00, 293.66, 370.00), // D major raga
                    listOf(164.81, 220.00, 329.63, 392.00), // E minor
                    listOf(196.00, 246.94, 293.66, 370.00), // G major
                    listOf(146.83, 220.00, 293.66, 440.00)  // D
                )
                AmbientMusicType.PARTY_BEATS -> listOf(
                    listOf(130.81, 196.00, 261.63, 311.13), // C min
                    listOf(116.54, 174.61, 233.08, 277.18), // Bb min
                    listOf(103.83, 155.56, 207.65, 261.63), // Ab maj
                    listOf(98.00, 146.83, 196.00, 246.94)   // G maj
                )
            }

            var chordIndex = 0
            while (isActive && isPlayingAmbient) {
                val currentChord = chords[chordIndex % chords.size]
                playSynthPad(currentChord, durationMs = 1800)
                chordIndex++
                delay(100)
            }
        }
    }

    private fun playApplause() {
        val durationMs = 2200
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)
        val random = Random.Default

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val envelope = when {
                time < 0.3f -> time / 0.3f
                time > 1.8f -> (2.2f - time) / 0.4f
                else -> 1.0f
            }
            val whiteNoise = (random.nextFloat() * 2f - 1f)
            val burst = sin(2 * PI * 18 * time).toFloat().coerceAtLeast(0f) * 0.5f + 0.5f
            buffer[i] = (whiteNoise * burst * envelope * 12000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playCheers() {
        val durationMs = 2500
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)
        val random = Random.Default

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val envelope = when {
                time < 0.4f -> time / 0.4f
                time > 1.9f -> (2.5f - time) / 0.6f
                else -> 1.0f
            }
            val noise = (random.nextFloat() * 2f - 1f) * 0.6f
            val pitch1 = sin(2 * PI * (350 + 50 * sin(4 * PI * time)) * time).toFloat()
            val pitch2 = sin(2 * PI * (520 + 70 * sin(5 * PI * time)) * time).toFloat()
            val combined = (noise + pitch1 * 0.3f + pitch2 * 0.3f) * envelope
            buffer[i] = (combined * 13000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playFanfare() {
        val notes = listOf(261.63, 329.63, 392.00, 523.25, 659.25, 783.99)
        val noteDuration = 180
        val totalSamples = (sampleRate * (notes.size * noteDuration + 600) / 1000)
        val buffer = ShortArray(totalSamples)

        var sampleOffset = 0
        for ((index, freq) in notes.withIndex()) {
            val dur = if (index == notes.size - 1) noteDuration + 600 else noteDuration
            val noteSamples = (sampleRate * dur / 1000)
            for (i in 0 until noteSamples) {
                if (sampleOffset + i < totalSamples) {
                    val t = i.toFloat() / sampleRate
                    val envelope = when {
                        t < 0.03f -> t / 0.03f
                        t > (dur / 1000f - 0.05f) -> ((dur / 1000f) - t) / 0.05f
                        else -> 1.0f
                    }
                    val sample = (sin(2 * PI * freq * t) + 0.3 * sin(4 * PI * freq * t)).toFloat()
                    buffer[sampleOffset + i] = (sample * envelope * 16000).toInt().toShort()
                }
            }
            sampleOffset += (sampleRate * (noteDuration - 20) / 1000)
        }
        writeAndPlay(buffer)
    }

    private fun playPartyHorn() {
        val durationMs = 800
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val freq = 420.0 + 80.0 * (1.0 - time / 0.8)
            val envelope = when {
                time < 0.1f -> time / 0.1f
                time > 0.6f -> (0.8f - time) / 0.2f
                else -> 1.0f
            }
            // Sawtooth-like brass harmonic
            var sample = sin(2 * PI * freq * time)
            sample += 0.5 * sin(4 * PI * freq * time)
            sample += 0.25 * sin(6 * PI * freq * time)
            buffer[i] = (sample * envelope * 14000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playLaughter() {
        val durationMs = 1500
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val laughMod = (sin(2 * PI * 6.5 * time) * 0.5 + 0.5).toFloat()
            val freq = 360.0 + 120.0 * laughMod
            val envelope = (1.0f - time / 1.5f).coerceAtLeast(0f)
            val sample = sin(2 * PI * freq * time).toFloat() * laughMod * envelope
            buffer[i] = (sample * 14000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playGiftMagic() {
        val durationMs = 1200
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val sweepFreq = 600.0 + 1200.0 * (time / 1.2)
            val shimmer = sin(2 * PI * 24 * time).toFloat() * 0.3f + 0.7f
            val envelope = (1.0f - time / 1.2f).coerceAtLeast(0f)
            val sample = sin(2 * PI * sweepFreq * time).toFloat() * shimmer * envelope
            buffer[i] = (sample * 16000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playMicClick() {
        val durationMs = 100
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val decay = (1.0f - time / 0.1f).coerceAtLeast(0f)
            val sample = sin(2 * PI * 880 * time).toFloat() * decay
            buffer[i] = (sample * 15000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playHeartBeat() {
        val durationMs = 600
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val decay1 = (1.0f - (time / 0.15f)).coerceIn(0f, 1f)
            val decay2 = if (time > 0.22f) (1.0f - ((time - 0.22f) / 0.18f)).coerceIn(0f, 1f) else 0f
            val s1 = sin(2 * PI * 65.0 * time).toFloat() * decay1
            val s2 = sin(2 * PI * 60.0 * (time - 0.22f)).toFloat() * decay2
            buffer[i] = ((s1 + s2) * 18000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun playSynthPad(frequencies: List<Double>, durationMs: Int) {
        val totalSamples = (sampleRate * durationMs / 1000)
        val buffer = ShortArray(totalSamples)

        for (i in 0 until totalSamples) {
            val time = i.toFloat() / sampleRate
            val envelope = when {
                time < 0.4f -> time / 0.4f
                time > (durationMs / 1000f - 0.4f) -> ((durationMs / 1000f) - time) / 0.4f
                else -> 1.0f
            }
            var chordSample = 0.0
            for (freq in frequencies) {
                chordSample += sin(2 * PI * freq * time)
            }
            chordSample = (chordSample / frequencies.size) * envelope
            buffer[i] = (chordSample * 8000).toInt().toShort()
        }
        writeAndPlay(buffer)
    }

    private fun writeAndPlay(buffer: ShortArray) {
        var track: AudioTrack? = null
        try {
            val minBufferSize = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes((buffer.size * 2).coerceAtLeast(minBufferSize))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            track.write(buffer, 0, buffer.size)
            track.setNotificationMarkerPosition(buffer.size)
            track.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
                override fun onMarkerReached(t: AudioTrack?) {
                    try {
                        t?.stop()
                        t?.release()
                    } catch (_: Exception) {}
                }
                override fun onPeriodicNotification(t: AudioTrack?) {}
            })
            track.play()

            // Safety fallback release after duration + buffer
            val playDurationMs = (buffer.size * 1000L / sampleRate) + 500L
            scope.launch {
                delay(playDurationMs)
                try {
                    track.stop()
                    track.release()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {
            try { track?.release() } catch (_: Exception) {}
        }
    }

    fun release() {
        stopAmbientTrack()
    }
}

enum class SoundEffectType(val label: String, val emoji: String) {
    APPLAUSE("Applause", "👏"),
    CHEERS("Cheers", "🎉"),
    FANFARE("Fanfare", "🎺"),
    PARTY_HORN("Party Horn", "📯"),
    LAUGHTER("Laughter", "😂"),
    GIFT_MAGIC("Gift Magic", "✨"),
    MIC_CLICK("Mic Tap", "🎙️"),
    HEART_BEAT("Heart Beat", "💓")
}

enum class AmbientMusicType(val label: String, val description: String) {
    ROMANTIC_LOFI("Romantic Lo-Fi", "Calm acoustic guitar & piano loop"),
    RAGA_FUSION("Desi Raga & Sitar", "Traditional melodious fusion"),
    PARTY_BEATS("Club Party Beats", "Vibrant electronic dance rhythm")
}
