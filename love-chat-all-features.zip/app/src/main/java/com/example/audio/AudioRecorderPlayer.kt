package com.example.audio

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

class AudioRecorderPlayer(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var mediaPlayer: MediaPlayer? = null
    private var recordingFile: File? = null

    private val scope = CoroutineScope(Dispatchers.Main)
    private var amplitudeJob: Job? = null
    private var playbackJob: Job? = null

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0)
    val recordingDurationSeconds: StateFlow<Int> = _recordingDurationSeconds.asStateFlow()

    private val _currentAmplitude = MutableStateFlow(0f)
    val currentAmplitude: StateFlow<Float> = _currentAmplitude.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f)
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _activeAudioPath = MutableStateFlow<String?>(null)
    val activeAudioPath: StateFlow<String?> = _activeAudioPath.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    fun startRecording(): Boolean {
        try {
            stopPlayback()
            val outputDir = File(context.cacheDir, "voice_notes").apply { mkdirs() }
            val file = File(outputDir, "rec_${System.currentTimeMillis()}.m4a")
            recordingFile = file

            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }

            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }

            mediaRecorder = recorder
            _isRecording.value = true
            _recordingDurationSeconds.value = 0

            amplitudeJob = scope.launch {
                var secondsCounter = 0
                var subSecond = 0
                while (isActive && _isRecording.value) {
                    delay(100)
                    subSecond++
                    if (subSecond >= 10) {
                        secondsCounter++
                        _recordingDurationSeconds.value = secondsCounter
                        subSecond = 0
                    }
                    val maxAmp = try {
                        mediaRecorder?.maxAmplitude ?: 0
                    } catch (_: Exception) { 0 }
                    val normalized = (maxAmp / 32767f).coerceIn(0.05f, 1.0f)
                    _currentAmplitude.value = normalized
                }
            }
            return true
        } catch (_: Exception) {
            _isRecording.value = false
            return false
        }
    }

    fun stopRecording(): File? {
        if (!_isRecording.value) return null
        _isRecording.value = false
        amplitudeJob?.cancel()
        _currentAmplitude.value = 0f

        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (_: Exception) {}
        mediaRecorder = null

        return recordingFile
    }

    fun cancelRecording() {
        stopRecording()
        recordingFile?.delete()
        recordingFile = null
    }

    fun playAudio(path: String, onCompletion: () -> Unit = {}) {
        stopPlayback()
        val file = File(path)
        if (!file.exists()) {
            simulatePlayback(path, onCompletion)
            return
        }

        try {
            val player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    playbackParams = playbackParams.setSpeed(_playbackSpeed.value)
                }
                setOnCompletionListener {
                    _isPlaying.value = false
                    _playbackProgress.value = 0f
                    _activeAudioPath.value = null
                    onCompletion()
                }
                start()
            }
            mediaPlayer = player
            _isPlaying.value = true
            _activeAudioPath.value = path

            playbackJob = scope.launch {
                while (isActive && _isPlaying.value) {
                    delay(100)
                    val dur = player.duration.coerceAtLeast(1)
                    val pos = player.currentPosition
                    _playbackProgress.value = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
                }
            }
        } catch (_: IOException) {
            simulatePlayback(path, onCompletion)
        }
    }

    private fun simulatePlayback(path: String, onCompletion: () -> Unit) {
        _isPlaying.value = true
        _activeAudioPath.value = path
        playbackJob = scope.launch {
            val durationMs = 5000L
            val steps = 50
            for (i in 1..steps) {
                if (!isActive || !_isPlaying.value) break
                delay((durationMs / steps / _playbackSpeed.value).toLong())
                _playbackProgress.value = i.toFloat() / steps
            }
            _isPlaying.value = false
            _playbackProgress.value = 0f
            _activeAudioPath.value = null
            onCompletion()
        }
    }

    fun cyclePlaybackSpeed(): Float {
        val nextSpeed = when (_playbackSpeed.value) {
            1.0f -> 1.5f
            1.5f -> 2.0f
            else -> 1.0f
        }
        _playbackSpeed.value = nextSpeed
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            mediaPlayer?.let { player ->
                if (_isPlaying.value) {
                    try {
                        player.playbackParams = player.playbackParams.setSpeed(nextSpeed)
                    } catch (_: Exception) {}
                }
            }
        }
        return nextSpeed
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        _isPlaying.value = false
        _playbackProgress.value = 0f
        _activeAudioPath.value = null
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {}
        mediaPlayer = null
    }

    fun release() {
        cancelRecording()
        stopPlayback()
    }
}
