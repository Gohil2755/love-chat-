package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.AvailableGifts
import com.example.ui.GiftItem
import com.example.ui.RoomSpeaker
import com.example.ui.VoiceViewModel
import com.example.ui.components.GiftAnimationOverlay
import com.example.ui.components.SoundEffectsSheet
import com.example.ui.components.WaveformVisualizer
import com.example.ui.theme.BolAmber
import com.example.ui.theme.BolCoral
import com.example.ui.theme.BolDarkBg
import com.example.ui.theme.BolDarkSurface
import com.example.ui.theme.BolDarkSurfaceElevated
import com.example.ui.theme.BolGold
import com.example.ui.theme.BolPurple
import com.example.ui.theme.RoomGradients

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveVoiceRoomScreen(
    viewModel: VoiceViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.activeRoomState.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    var showGiftsSheet by remember { mutableStateOf(false) }
    var showSoundboard by remember { mutableStateOf(false) }
    var commentInput by remember { mutableStateOf("") }

    if (state == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("કોઈ સક્રિય રૂમ નથી", color = Color.White)
        }
        return
    }

    val roomState = state!!
    val room = roomState.room
    val gradient = RoomGradients.getOrElse(room.bannerGradientIndex % RoomGradients.size) { RoomGradients[0] }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(BolDarkBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(gradient)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = { viewModel.minimizeCurrentRoom() },
                        modifier = Modifier.testTag("btn_minimize_room")
                    ) {
                        Text(text = "🔽", fontSize = 20.sp)
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = room.title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🔴 લાઈવ • ${room.listenersCount} શ્રોતાઓ",
                                color = Color.White.copy(alpha = 0.85f),
                                fontSize = 11.sp
                            )
                        }
                    }

                    Row {
                        IconButton(
                            onClick = { showSoundboard = true },
                            modifier = Modifier.testTag("btn_open_soundboard")
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Soundboard",
                                tint = BolGold
                            )
                        }

                        IconButton(
                            onClick = { viewModel.leaveVoiceRoom() },
                            modifier = Modifier.testTag("btn_leave_room")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Leave",
                                tint = Color.White
                            )
                        }
                    }
                }
            }

            // Central Speaker Stage (8 Seats Grid)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(BolDarkSurface)
                    .padding(16.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🎙️ સ્પીકર સ્ટેજ (Stage Seats)",
                            color = BolGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        WaveformVisualizer(
                            barCount = 14,
                            isLive = true,
                            amplitude = 0.8f,
                            primaryColor = BolCoral,
                            secondaryColor = BolAmber,
                            height = 18.dp,
                            modifier = Modifier.width(70.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(8) { seatIndex ->
                            val speaker = roomState.speakers.find { it.seatIndex == seatIndex }
                            SpeakerSeatItem(
                                seatIndex = seatIndex,
                                speaker = speaker,
                                isMe = speaker?.userId == userProfile?.userId,
                                onSeatClick = {
                                    if (speaker == null) {
                                        viewModel.takeSpeakerSeat(seatIndex)
                                    } else if (speaker.userId == userProfile?.userId) {
                                        viewModel.leaveSpeakerSeat()
                                    }
                                }
                            )
                        }
                    }
                }
            }

            // Audience Strip
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "ઓડિયન્સ (${roomState.audience.size}): ",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 12.sp
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp)
                ) {
                    items(roomState.audience) { aud ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(BolDarkSurfaceElevated),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = aud.avatarEmoji, fontSize = 14.sp)
                        }
                    }
                }
            }

            // Live Chat Comments Stream
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(roomState.comments, key = { it.id }) { comment ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(BolDarkSurfaceElevated.copy(alpha = 0.7f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${comment.senderName}: ",
                                color = BolAmber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = comment.text,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            // Floating Emoji Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf("❤️", "💖", "🔥", "👏", "🌹", "😂", "✨").forEach { emoji ->
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(BolDarkSurfaceElevated)
                            .clickable { viewModel.sendFloatingReaction(emoji) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = emoji, fontSize = 18.sp)
                    }
                }
            }

            // Bottom Input & Controls Bar
            Surface(
                color = BolDarkSurface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = commentInput,
                        onValueChange = { commentInput = it },
                        placeholder = { Text("ચેટમાં કંઈક કહો...", color = Color.Gray, fontSize = 13.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = BolPurple,
                            unfocusedBorderColor = Color.DarkGray
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("room_comment_input"),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true,
                        trailingIcon = {
                            if (commentInput.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        viewModel.sendRoomComment(commentInput)
                                        commentInput = ""
                                    },
                                    modifier = Modifier.testTag("btn_send_comment")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Send,
                                        contentDescription = "Send",
                                        tint = BolCoral
                                    )
                                }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Mic Mute Button (if on stage)
                    if (roomState.mySeatIndex != null) {
                        IconButton(
                            onClick = { viewModel.toggleMyMic() },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(if (roomState.isMyMicMuted) BolCoral else BolPurple)
                                .testTag("btn_live_mic_toggle")
                        ) {
                            Icon(
                                imageVector = if (roomState.isMyMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = "Toggle Mic",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Gift Button
                    IconButton(
                        onClick = { showGiftsSheet = true },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    listOf(BolGold, BolCoral)
                                )
                            )
                            .testTag("btn_open_gifts")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CardGiftcard,
                            contentDescription = "Send Gift",
                            tint = Color.White
                        )
                    }
                }
            }
        }

        // Overlay for Gifts and Reactions
        GiftAnimationOverlay(
            activeGift = roomState.activeGiftBanner,
            senderName = roomState.activeGiftSender,
            floatingEmojis = roomState.floatingEmojis
        )
    }

    if (showGiftsSheet) {
        GiftsBottomSheet(
            userCoins = userProfile?.coins ?: 0,
            onSendGift = { gift ->
                viewModel.sendGift(gift)
                showGiftsSheet = false
            },
            onClaimCoins = { viewModel.claimDailyBonusCoins() },
            onDismiss = { showGiftsSheet = false }
        )
    }

    if (showSoundboard) {
        SoundEffectsSheet(
            soundEngine = viewModel.soundEngine,
            onDismiss = { showSoundboard = false }
        )
    }
}

@Composable
fun SpeakerSeatItem(
    seatIndex: Int,
    speaker: RoomSpeaker?,
    isMe: Boolean,
    onSeatClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "speaker_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (speaker?.isSpeaking == true) 1.15f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable { onSeatClick() }
            .testTag("speaker_seat_$seatIndex")
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .scale(if (speaker?.isSpeaking == true) pulseScale else 1f)
                .clip(CircleShape)
                .background(
                    when {
                        speaker?.isHost == true -> Brush.linearGradient(listOf(BolGold, BolAmber))
                        speaker != null -> Brush.linearGradient(listOf(BolPurple, BolCoral))
                        else -> Brush.linearGradient(listOf(BolDarkSurfaceElevated, BolDarkSurfaceElevated))
                    }
                )
                .border(
                    width = if (speaker?.isSpeaking == true) 2.5.dp else 1.dp,
                    color = when {
                        speaker?.isSpeaking == true -> BolGold
                        speaker?.isHost == true -> BolAmber
                        else -> Color.DarkGray
                    },
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (speaker != null) {
                Text(text = speaker.avatarEmoji, fontSize = 24.sp)
                if (speaker.isMuted) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(BolCoral),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MicOff,
                            contentDescription = "Muted",
                            tint = Color.White,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
            } else {
                Text(
                    text = "+",
                    color = Color.Gray,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = when {
                speaker?.isHost == true -> "👑 ${speaker.name.take(6)}"
                speaker != null -> if (isMe) "તમે (You)" else speaker.name.take(6)
                else -> "${seatIndex + 1} સીટ"
            },
            color = if (speaker != null) Color.White else Color.Gray,
            fontSize = 11.sp,
            fontWeight = if (speaker != null) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GiftsBottomSheet(
    userCoins: Int,
    onSendGift: (GiftItem) -> Unit,
    onClaimCoins: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 32.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CardGiftcard,
                        contentDescription = null,
                        tint = BolCoral,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ગિફ્ટ સ્ટોર (Send Love Gifts)",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Balance Pill
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = BolGold.copy(alpha = 0.2f),
                    modifier = Modifier.clickable { onClaimCoins() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MonetizationOn,
                            contentDescription = null,
                            tint = BolGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$userCoins કોઈન્સ (+250)",
                            color = BolGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(AvailableGifts) { gift ->
                    val canAfford = userCoins >= gift.coinPrice
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (canAfford) MaterialTheme.colorScheme.surfaceVariant
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier
                            .clickable(enabled = canAfford) { onSendGift(gift) }
                            .testTag("gift_${gift.id}")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Text(text = gift.emoji, fontSize = 36.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = gift.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = BolGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(
                                    text = "${gift.coinPrice}",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (canAfford) BolGold else Color.Gray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
