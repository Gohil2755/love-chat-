package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Primary Social & Party Colors
val BolPurple = Color(0xFF7C3AED)
val BolPurpleDark = Color(0xFF5B21B6)
val BolIndigo = Color(0xFF4F46E5)
val BolCoral = Color(0xFFFF3366)
val BolAmber = Color(0xFFFFB703)
val BolGold = Color(0xFFFFD166)
val BolEmerald = Color(0xFF10B981)
val BolTeal = Color(0xFF06D6A0)
val BolSky = Color(0xFF38BDF8)

// Dark Theme Surfaces
val BolDarkBg = Color(0xFF0F0E17)
val BolDarkSurface = Color(0xFF1B1A28)
val BolDarkSurfaceElevated = Color(0xFF26253B)
val BolDarkCard = Color(0xFF212034)

// Light Theme Surfaces
val BolLightBg = Color(0xFFF8FAFC)
val BolLightSurface = Color(0xFFFFFFFF)
val BolLightCard = Color(0xFFF1F5F9)

// Accent Gradients
val GradientSunset = Brush.horizontalGradient(listOf(Color(0xFFFF512F), Color(0xFFDD2476)))
val GradientPurpleParty = Brush.horizontalGradient(listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFFF27121)))
val GradientOcean = Brush.horizontalGradient(listOf(Color(0xFF2E3192), Color(0xFF1BFFFF)))
val GradientEmerald = Brush.horizontalGradient(listOf(Color(0xFF0BA360), Color(0xFF3CBA92)))
val GradientGold = Brush.horizontalGradient(listOf(Color(0xFFF7971E), Color(0xFFFFD200)))
val GradientRoyal = Brush.horizontalGradient(listOf(Color(0xFF654EA3), Color(0xFFEAAFC8)))

val RoomGradients = listOf(
    Brush.linearGradient(listOf(Color(0xFF4A00E0), Color(0xFF8E2DE2))),
    Brush.linearGradient(listOf(Color(0xFFFF416C), Color(0xFFFF4B2B))),
    Brush.linearGradient(listOf(Color(0xFF00B4DB), Color(0xFF0083B0))),
    Brush.linearGradient(listOf(Color(0xFFF7971E), Color(0xFFFFD200))),
    Brush.linearGradient(listOf(Color(0xFF11998E), Color(0xFF38EF7D))),
    Brush.linearGradient(listOf(Color(0xFF834D9B), Color(0xFFD04ED6)))
)
