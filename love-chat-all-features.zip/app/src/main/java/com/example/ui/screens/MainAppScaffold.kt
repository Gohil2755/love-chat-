package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.ScreenDestination
import com.example.ui.VoiceViewModel
import com.example.ui.components.FloatingAudioRoomBar
import com.example.ui.theme.BolAmber
import com.example.ui.theme.BolCoral
import com.example.ui.theme.BolGold
import com.example.ui.theme.BolPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(
    viewModel: VoiceViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val minimizedRoom by viewModel.minimizedRoom.collectAsStateWithLifecycle()
    val activeRoomState by viewModel.activeRoomState.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()

    val isInsideActiveRoom = currentScreen is ScreenDestination.ActiveVoiceRoom
    val isInsideChatDetail = currentScreen is ScreenDestination.GroupChatDetail

    Scaffold(
        topBar = {
            if (!isInsideActiveRoom && !isInsideChatDetail) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "❤️", fontSize = 22.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Love Chat",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp,
                                color = BolPurple
                            )
                        }
                    },
                    actions = {
                        // Virtual Coins counter in Top Bar
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = BolGold.copy(alpha = 0.15f),
                            modifier = Modifier
                                .clickable { viewModel.navigateTo(ScreenDestination.Profile) }
                                .padding(end = 12.dp)
                                .testTag("topbar_coins_badge")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = BolGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${userProfile?.coins ?: 1250}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        },
        bottomBar = {
            if (!isInsideActiveRoom) {
                Box {
                    // Minimized Floating Audio Room
                    minimizedRoom?.let { room ->
                        FloatingAudioRoomBar(
                            room = room,
                            isMyMicMuted = activeRoomState?.isMyMicMuted ?: false,
                            isOnStage = activeRoomState?.mySeatIndex != null,
                            onExpand = {
                                viewModel.navigateTo(ScreenDestination.ActiveVoiceRoom(room.id))
                            },
                            onToggleMic = { viewModel.toggleMyMic() },
                            onLeave = { viewModel.leaveVoiceRoom() },
                            modifier = Modifier.padding(bottom = 70.dp)
                        )
                    }

                    if (!isInsideChatDetail) {
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface,
                            tonalElevation = 8.dp,
                            modifier = Modifier.testTag("main_bottom_nav")
                        ) {
                            NavigationBarItem(
                                selected = currentScreen is ScreenDestination.VoiceRoomsList,
                                onClick = { viewModel.navigateTo(ScreenDestination.VoiceRoomsList) },
                                icon = { Icon(Icons.Default.Podcasts, contentDescription = "Voice Club") },
                                label = { Text("ઓડિયો ક્લબ", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = BolPurple,
                                    selectedTextColor = BolPurple,
                                    indicatorColor = BolPurple.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_item_rooms")
                            )

                            NavigationBarItem(
                                selected = currentScreen is ScreenDestination.GroupChatsList,
                                onClick = { viewModel.navigateTo(ScreenDestination.GroupChatsList) },
                                icon = { Icon(Icons.Default.Chat, contentDescription = "Group Chat") },
                                label = { Text("ગ્રુપ ચેટ", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = BolCoral,
                                    selectedTextColor = BolCoral,
                                    indicatorColor = BolCoral.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_item_chats")
                            )

                            NavigationBarItem(
                                selected = currentScreen is ScreenDestination.SocialFeed,
                                onClick = { viewModel.navigateTo(ScreenDestination.SocialFeed) },
                                icon = { Icon(Icons.Default.DynamicFeed, contentDescription = "Share Feed") },
                                label = { Text("શેર ફીડ", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = BolAmber,
                                    selectedTextColor = BolAmber,
                                    indicatorColor = BolAmber.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_item_feed")
                            )

                            NavigationBarItem(
                                selected = currentScreen is ScreenDestination.CommunityHub,
                                onClick = { viewModel.navigateTo(ScreenDestination.CommunityHub) },
                                icon = { Icon(Icons.Default.AutoAwesome, contentDescription = "Community") },
                                label = { Text("કમ્યુનિટી", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = BolPurple,
                                    selectedTextColor = BolPurple,
                                    indicatorColor = BolPurple.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_item_community")
                            )

                            NavigationBarItem(
                                selected = currentScreen is ScreenDestination.Profile,
                                onClick = { viewModel.navigateTo(ScreenDestination.Profile) },
                                icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                                label = { Text("પ્રોફાઇલ", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = BolPurple,
                                    selectedTextColor = BolPurple,
                                    indicatorColor = BolPurple.copy(alpha = 0.15f)
                                ),
                                modifier = Modifier.testTag("nav_item_profile")
                            )
                        }
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val dest = currentScreen) {
                is ScreenDestination.VoiceRoomsList -> {
                    VoiceRoomsScreen(viewModel = viewModel)
                }
                is ScreenDestination.ActiveVoiceRoom -> {
                    LiveVoiceRoomScreen(viewModel = viewModel)
                }
                is ScreenDestination.GroupChatsList -> {
                    GroupChatsScreen(viewModel = viewModel)
                }
                is ScreenDestination.GroupChatDetail -> {
                    ChatDetailScreen(
                        groupId = dest.groupId,
                        viewModel = viewModel,
                        onBack = { viewModel.navigateTo(ScreenDestination.GroupChatsList) }
                    )
                }
                is ScreenDestination.SocialFeed -> {
                    SocialFeedScreen(viewModel = viewModel)
                }
                is ScreenDestination.CommunityHub -> {
                    CommunityHubScreen(viewModel = viewModel)
                }
                is ScreenDestination.Profile -> {
                    ProfileScreen(viewModel = viewModel)
                }
            }
        }
    }
}
