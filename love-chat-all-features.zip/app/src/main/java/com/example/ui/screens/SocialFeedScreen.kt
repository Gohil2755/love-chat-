package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.SocialPostEntity
import com.example.ui.VoiceViewModel
import com.example.ui.components.WaveformVisualizer
import com.example.ui.theme.BolAmber
import com.example.ui.theme.BolCoral
import com.example.ui.theme.BolGold
import com.example.ui.theme.BolPurple
import com.example.ui.theme.GradientSunset

val FeedTags = listOf("બધા (All)", "લવ સ્ટેટસ ❤️", "શાયરી 📜", "ગરબા 💃", "સુવિચાર ✨", "મસ્તી 😂")

@Composable
fun SocialFeedScreen(
    viewModel: VoiceViewModel,
    modifier: Modifier = Modifier
) {
    val posts by viewModel.socialPosts.collectAsStateWithLifecycle()
    var selectedTag by remember { mutableStateOf("બધા (All)") }
    var showCreatePostDialog by remember { mutableStateOf(false) }

    val filteredPosts = remember(posts, selectedTag) {
        if (selectedTag.startsWith("બધા")) posts
        else posts.filter { it.categoryTag.contains(selectedTag.take(4), ignoreCase = true) }
    }

    val isPlaying by viewModel.audioRecorderPlayer.isPlaying.collectAsStateWithLifecycle()
    val activePath by viewModel.audioRecorderPlayer.activeAudioPath.collectAsStateWithLifecycle()
    val playbackProgress by viewModel.audioRecorderPlayer.playbackProgress.collectAsStateWithLifecycle()

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreatePostDialog = true },
                containerColor = BolCoral,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier.testTag("fab_create_post")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 16.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New Post")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("પોસ્ટ કરો", fontWeight = FontWeight.Bold)
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp)
        ) {
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(FeedTags) { tag ->
                        val isSel = selectedTag == tag
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(18.dp))
                                .background(if (isSel) BolPurple else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedTag = tag }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = tag,
                                color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(filteredPosts, key = { it.id }) { post ->
                SocialPostCard(
                    post = post,
                    isPlaying = isPlaying && activePath == post.audioSnippetPath,
                    playbackProgress = if (activePath == post.audioSnippetPath) playbackProgress else 0f,
                    onPlay = { path -> viewModel.audioRecorderPlayer.playAudio(path) },
                    onStop = { viewModel.audioRecorderPlayer.stopPlayback() },
                    onLike = { viewModel.toggleLikePost(post) },
                    onShare = { viewModel.sharePost(post) }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    if (showCreatePostDialog) {
        CreatePostDialog(
            onDismiss = { showCreatePostDialog = false },
            onCreate = { text, tag ->
                viewModel.createSocialPost(text, tag)
                showCreatePostDialog = false
            }
        )
    }
}

@Composable
fun SocialPostCard(
    post: SocialPostEntity,
    isPlaying: Boolean,
    playbackProgress: Float,
    onPlay: (String) -> Unit,
    onStop: () -> Unit,
    onLike: () -> Unit,
    onShare: () -> Unit
) {
    val context = LocalContext.current

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .testTag("social_post_${post.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Author Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(BolPurple.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = post.authorAvatar, fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = post.authorName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = BolGold.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = post.authorBadge,
                                    color = BolGold,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "${post.authorHandle} • ${post.timeAgo}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = BolPurple.copy(alpha = 0.1f)
                ) {
                    Text(
                        text = post.categoryTag,
                        color = BolPurple,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Post Text
            Text(
                text = post.contentText,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Audio Player Box (if audio snippet attached)
            if (post.audioSnippetPath != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(BolPurple, BolCoral)
                            )
                        )
                        .padding(14.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        if (isPlaying) onStop() else onPlay(post.audioSnippetPath)
                                    },
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                ) {
                                    Icon(
                                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play Audio",
                                        tint = BolPurple
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = post.audioTitle ?: "ઓડિયો સ્ટેટસ",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "🎙️ ${post.audioDurationSeconds} સેકન્ડ્સ",
                                        color = Color.White.copy(alpha = 0.8f),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            WaveformVisualizer(
                                barCount = 12,
                                isLive = isPlaying,
                                amplitude = if (isPlaying) 0.8f else 0.2f,
                                primaryColor = Color.White,
                                secondaryColor = BolGold,
                                height = 20.dp,
                                modifier = Modifier.width(70.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        LinearProgressIndicator(
                            progress = { playbackProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = Color.White,
                            trackColor = Color.White.copy(alpha = 0.3f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons (Like, Comment, Share)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onLike() }
                ) {
                    Icon(
                        imageVector = if (post.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (post.isLiked) BolCoral else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${post.likesCount}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (post.isLiked) BolCoral else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Comments",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${post.commentsCount}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable {
                        onShare()
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, "${post.contentText}\n\n- Love Chat & BolChat પરથી શેર કરેલ")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "શેર કરો"))
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = BolPurple,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${post.sharesCount} શેર",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = BolPurple
                    )
                }
            }
        }
    }
}

@Composable
fun CreatePostDialog(
    onDismiss: () -> Unit,
    onCreate: (text: String, tag: String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    var selectedTag by remember { mutableStateOf("લવ સ્ટેટસ") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("નવી શેરચેટ પોસ્ટ લખો ✨", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("તમારા દિલની વાત, શાયરી અથવા સુવિચાર લખો...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .testTag("input_post_text"),
                    maxLines = 5
                )

                Text(text = "ટેગ પસંદ કરો:", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                val tags = listOf("લવ સ્ટેટસ", "શાયરી", "ગરબા", "સુવિચાર", "મસ્તી")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(tags) { t ->
                        val isSel = selectedTag == t
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSel) BolPurple else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedTag = t }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = t,
                                fontSize = 12.sp,
                                color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (text.isNotBlank()) onCreate(text, selectedTag)
                },
                colors = ButtonDefaults.buttonColors(containerColor = BolPurple),
                modifier = Modifier.testTag("btn_confirm_post")
            ) {
                Text("પોસ્ટ કરો 🚀")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("રદ કરો") }
        }
    )
}
