package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.BolCoral
import com.example.ui.theme.BolPurple
import kotlin.math.sin

@Composable
fun WaveformVisualizer(
    modifier: Modifier = Modifier,
    barCount: Int = 28,
    isLive: Boolean = true,
    amplitude: Float = 0.5f,
    primaryColor: Color = BolPurple,
    secondaryColor: Color = BolCoral,
    height: Dp = 40.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        val totalWidth = size.width
        val canvasHeight = size.height
        val barWidth = (totalWidth / (barCount * 1.5f)).coerceIn(4f, 16f)
        val spacing = barWidth * 0.5f

        for (i in 0 until barCount) {
            val progress = i.toFloat() / barCount
            val wave = if (isLive) {
                (sin(progress * 8f + phase) * 0.4f + 0.6f) * amplitude.coerceAtLeast(0.15f)
            } else {
                0.15f
            }

            val barHeight = (canvasHeight * wave).coerceIn(4f, canvasHeight)
            val startX = i * (barWidth + spacing)
            val startY = (canvasHeight - barHeight) / 2f

            val brush = Brush.verticalGradient(
                colors = listOf(primaryColor, secondaryColor),
                startY = startY,
                endY = startY + barHeight
            )

            drawRoundRect(
                brush = brush,
                topLeft = Offset(startX, startY),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}
