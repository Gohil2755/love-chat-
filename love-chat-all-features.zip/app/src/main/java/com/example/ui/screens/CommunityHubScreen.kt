package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ScreenDestination
import com.example.ui.VoiceViewModel
import com.example.ui.theme.BolAmber
import com.example.ui.theme.BolCoral
import com.example.ui.theme.BolGold
import com.example.ui.theme.BolPurple

data class ReelDraft(val title: String, val views: Int = 0)

@Composable
fun CommunityHubScreen(viewModel: VoiceViewModel, modifier: Modifier = Modifier) {
    var tab by remember { mutableStateOf(0) }
    var postText by remember { mutableStateOf("") }
    var reelTitle by remember { mutableStateOf("") }
    var showPost by remember { mutableStateOf(false) }
    var showReel by remember { mutableStateOf(false) }
    var isPrivate by remember { mutableStateOf(false) }
    var followers by remember { mutableStateOf(340) }
    var requests by remember { mutableStateOf(3) }
    var coins by remember { mutableStateOf(1250) }
    var level by remember { mutableStateOf(7) }
    val reels = remember { mutableStateListOf<ReelDraft>() }
    val gifts = listOf("💖","🌹","🎁","👑","🚀","💎","🎸","🔥","✨","🦄","🐯","🍫")

    Column(modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Home","Posts","Reels","Live","Profile").forEachIndexed { i, t ->
                FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) })
            }
        }
        when (tab) {
            0 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card(shape = RoundedCornerShape(24.dp)) {
                        Box(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(BolPurple, BolCoral, BolAmber))).padding(20.dp)) {
                            Column {
                                Text("❤️ Love Chat Community", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                                Text("Snapchat જેવી social + live audio community", color = Color.White.copy(.9f))
                                Spacer(Modifier.height(14.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    AssistChip(onClick = { tab = 1 }, label = { Text("➕ Post") })
                                    AssistChip(onClick = { tab = 2 }, label = { Text("🎬 Reel") })
                                    AssistChip(onClick = { tab = 3 }, label = { Text("🔴 Live Audio") })
                                }
                            }
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("🏆 Level $level / 50", fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(progress = { level / 50f }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                            Text("Time & activityથી levels unlock થશે")
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("🪙 $coins Coins", fontWeight = FontWeight.Bold)
                            Text("🎁 Gifts અને stickers માટે")
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                gifts.take(6).forEach { Text(it, fontSize = 28.sp) }
                            }
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("👥 Follow System", fontWeight = FontWeight.Bold)
                            Text("$followers Followers  •  $requests Follow Requests")
                            Button(onClick = { requests++ }) { Text("Demo Request") }
                        }
                    }
                }
            }
            1 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("📝 Create Post", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        FloatingActionButton(onClick = { showPost = true }) { Icon(Icons.Default.Add, null) }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("Photo / Video Post")
                            Text("Caption, likes, comments અને shares અહીં જોડાશે.")
                            Button(onClick = { showPost = true }) { Text("Create Post") }
                        }
                    }
                }
            }
            2 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("🎬 Reels", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        FloatingActionButton(onClick = { showReel = true }) { Icon(Icons.Default.Add, null) }
                    }
                }
                items(reels) { r ->
                    Card {
                        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("🎬 ${r.title}")
                            Text("${r.views} views • 🪙 reward")
                        }
                    }
                }
                if (reels.isEmpty()) item { Text("હજુ Reel નથી. + દબાવીને પહેલી Reel બનાવો.") }
            }
            3 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card {
                        Column(Modifier.padding(18.dp)) {
                            Text("🔴 Live Audio Chat", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Lobby • Audience • Speaker Seats • Request • Admin • Comments • Music • Gifts")
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { viewModel.navigateTo(ScreenDestination.VoiceRoomsList) }) {
                                Icon(Icons.Default.Podcasts, null)
                                Spacer(Modifier.width(6.dp))
                                Text("Live Audio Rooms")
                            }
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("🎁 Gift Stickers", fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                gifts.forEach { g -> AssistChip(onClick = { if (coins >= 10) coins -= 10 }, label = { Text(g) }) }
                            }
                            Text("દરેક gift coinsથી મોકલાશે.")
                        }
                    }
                }
            }
            4 -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card {
                        Column(Modifier.padding(18.dp)) {
                            Text("👤 Profile", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("@love_creator")
                            Text("❤️ Love Chat creator • Level $level")
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text("$followers Followers")
                                Text("128 Following")
                            }
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(if (isPrivate) "🔒 Private Account" else "🌐 Public Account", fontWeight = FontWeight.Bold)
                                Switch(checked = isPrivate, onCheckedChange = { isPrivate = it })
                            }
                            Text(if (isPrivate) "Follow માટે request અને approval જરૂરી." else "કોઈપણ તમને follow કરી શકે.")
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("🏆 50 Level System", fontWeight = FontWeight.Bold)
                            Text("Level $level / 50")
                            LinearProgressIndicator(progress = { level / 50f }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                            Button(onClick = { if (level < 50) level++ }) { Text("Activity Reward") }
                        }
                    }
                }
                item {
                    Card {
                        Column(Modifier.padding(16.dp)) {
                            Text("💰 Wallet", fontWeight = FontWeight.Bold)
                            Text("$coins Coins")
                            Text("Reel views, time spent અને gifts માટે reward system")
                        }
                    }
                }
            }
        }
    }

    if (showPost) {
        AlertDialog(
            onDismissRequest = { showPost = false },
            title = { Text("Create Post") },
            text = { OutlinedTextField(postText, { postText = it }, label = { Text("Caption") }) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.createSocialPost(postText.ifBlank { "❤️ Love Chat post" }, "Social")
                    postText = ""; showPost = false
                }) { Text("Post") }
            },
            dismissButton = { TextButton(onClick = { showPost = false }) { Text("Cancel") } }
        )
    }
    if (showReel) {
        AlertDialog(
            onDismissRequest = { showReel = false },
            title = { Text("Create Reel") },
            text = { OutlinedTextField(reelTitle, { reelTitle = it }, label = { Text("Reel title/caption") }) },
            confirmButton = {
                TextButton(onClick = {
                    reels.add(ReelDraft(reelTitle.ifBlank { "My New Reel" }))
                    reelTitle = ""; showReel = false
                }) { Text("Create Reel") }
            },
            dismissButton = { TextButton(onClick = { showReel = false }) { Text("Cancel") }
            }
        )
    }
}
