package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AmbientMusicType
import com.example.audio.AudioRecorderPlayer
import com.example.audio.SoundEffectType
import com.example.audio.SoundEffectsEngine
import com.example.data.VoiceRepository
import com.example.data.local.AppDatabase
import com.example.data.local.ChatMessageEntity
import com.example.data.local.GroupChatEntity
import com.example.data.local.SocialPostEntity
import com.example.data.local.UserProfileEntity
import com.example.data.local.VoiceRoomEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

sealed class ScreenDestination {
    data object VoiceRoomsList : ScreenDestination()
    data class ActiveVoiceRoom(val roomId: String) : ScreenDestination()
    data object GroupChatsList : ScreenDestination()
    data class GroupChatDetail(val groupId: String) : ScreenDestination()
    data object SocialFeed : ScreenDestination()
    data object CommunityHub : ScreenDestination()
    data object Profile : ScreenDestination()
}

data class RoomSpeaker(
    val seatIndex: Int,
    val userId: String,
    val name: String,
    val avatarEmoji: String,
    val isHost: Boolean = false,
    val isMuted: Boolean = false,
    val isSpeaking: Boolean = false,
    val audioLevel: Float = 0f
)

data class RoomAudience(
    val userId: String,
    val name: String,
    val avatarEmoji: String
)

data class LiveRoomComment(
    val id: String = System.currentTimeMillis().toString(),
    val senderName: String,
    val text: String,
    val badge: String = "VIP"
)

data class FloatingEmoji(
    val id: Long = System.currentTimeMillis() + Random.nextLong(1000),
    val emoji: String,
    val startXRatio: Float = Random.nextFloat() * 0.8f + 0.1f
)

data class GiftItem(
    val id: String,
    val name: String,
    val emoji: String,
    val coinPrice: Int,
    val animationDescription: String
)

val AvailableGifts = listOf(
    GiftItem("gift_heart", "લવ હાર્ટ", "💖", 10, "Romantic Heart shower"),
    GiftItem("gift_rose", "ગુલાબ", "🌹", 20, "Rose petals celebration"),
    GiftItem("gift_chai", "કડક ચા", "☕", 50, "Surti Chai cheers"),
    GiftItem("gift_jalebi", "જલેબી ફાફડા", "🥨", 100, "Gujarati festive delight"),
    GiftItem("gift_mic", "ગોલ્ડન માઈક", "🎙️", 250, "Golden microphone spotlight"),
    GiftItem("gift_crown", "શાહી મુગટ", "👑", 500, "Royal Crown VIP fireworks"),
    GiftItem("gift_rocket", "સુપર રોકેટ", "🚀", 1000, "Super Rocket galaxy boost")
)

data class ActiveRoomState(
    val room: VoiceRoomEntity,
    val speakers: List<RoomSpeaker>,
    val audience: List<RoomAudience>,
    val comments: List<LiveRoomComment>,
    val floatingEmojis: List<FloatingEmoji> = emptyList(),
    val activeGiftBanner: GiftItem? = null,
    val activeGiftSender: String? = null,
    val isMyMicMuted: Boolean = false,
    val mySeatIndex: Int? = null
)

class VoiceViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = VoiceRepository(database.voiceDao())

    val soundEngine = SoundEffectsEngine()
    val audioRecorderPlayer = AudioRecorderPlayer(application)

    private val _currentScreen = MutableStateFlow<ScreenDestination>(ScreenDestination.VoiceRoomsList)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    val voiceRooms: StateFlow<List<VoiceRoomEntity>> = repository.getAllVoiceRooms()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val groupChats: StateFlow<List<GroupChatEntity>> = repository.getAllGroupChats()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val socialPosts: StateFlow<List<SocialPostEntity>> = repository.getAllSocialPosts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userProfile: StateFlow<UserProfileEntity?> = repository.getUserProfile()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _activeRoomState = MutableStateFlow<ActiveRoomState?>(null)
    val activeRoomState: StateFlow<ActiveRoomState?> = _activeRoomState.asStateFlow()

    private val _minimizedRoom = MutableStateFlow<VoiceRoomEntity?>(null)
    val minimizedRoom: StateFlow<VoiceRoomEntity?> = _minimizedRoom.asStateFlow()

    private var roomSimulationJob: Job? = null

    init {
        // Ensure initial user profile exists
        viewModelScope.launch {
            if (userProfile.value == null) {
                repository.updateUserProfile(UserProfileEntity())
            }
        }
    }

    fun navigateTo(destination: ScreenDestination) {
        _currentScreen.value = destination
    }

    fun joinVoiceRoom(room: VoiceRoomEntity) {
        val initialSpeakers = mutableListOf(
            RoomSpeaker(0, "host_1", room.hostName, room.hostAvatar, isHost = true, isMuted = false, isSpeaking = true),
            RoomSpeaker(1, "spk_1", "આરવ પટેલ", "🎸", isHost = false, isMuted = false, isSpeaking = false),
            RoomSpeaker(2, "spk_2", "પ્રિયા શાહ", "🌸", isHost = false, isMuted = true, isSpeaking = false),
            RoomSpeaker(3, "spk_3", "કલ્પેશ ભાઈ", "🤠", isHost = false, isMuted = false, isSpeaking = true)
        )

        val initialAudience = listOf(
            RoomAudience("aud_1", "રોહન", "🎧"),
            RoomAudience("aud_2", "નેહા", "✨"),
            RoomAudience("aud_3", "પૂજા", "💖"),
            RoomAudience("aud_4", "વિક્રમ", "🦁"),
            RoomAudience("aud_5", "દિશા", "🌺"),
            RoomAudience("aud_6", "મનન", "🚀")
        )

        val initialComments = listOf(
            LiveRoomComment("c1", "નેહા", "ખૂબ જ સરસ શાયરી! ❤️"),
            LiveRoomComment("c2", "વિક્રમ", "જય શ્રી કૃષ્ણ બધાને 🙏"),
            LiveRoomComment("c3", "પૂજા", "આગળ નવું ગીત ગાઓ 🎶")
        )

        _activeRoomState.value = ActiveRoomState(
            room = room,
            speakers = initialSpeakers,
            audience = initialAudience,
            comments = initialComments,
            isMyMicMuted = false,
            mySeatIndex = null
        )

        _minimizedRoom.value = null
        _currentScreen.value = ScreenDestination.ActiveVoiceRoom(room.id)
        startRoomSimulation()
    }

    fun minimizeCurrentRoom() {
        _minimizedRoom.value = _activeRoomState.value?.room
        _currentScreen.value = ScreenDestination.VoiceRoomsList
    }

    fun leaveVoiceRoom() {
        roomSimulationJob?.cancel()
        soundEngine.stopAmbientTrack()
        _activeRoomState.value = null
        _minimizedRoom.value = null
        _currentScreen.value = ScreenDestination.VoiceRoomsList
    }

    fun takeSpeakerSeat(seatIndex: Int) {
        val currentState = _activeRoomState.value ?: return
        val profile = userProfile.value ?: UserProfileEntity()
        val updatedSpeakers = currentState.speakers.toMutableList()

        val existingSeat = updatedSpeakers.indexOfFirst { it.seatIndex == seatIndex }
        if (existingSeat == -1) {
            val mySpeaker = RoomSpeaker(
                seatIndex = seatIndex,
                userId = profile.userId,
                name = profile.name,
                avatarEmoji = profile.avatarEmoji,
                isHost = false,
                isMuted = currentState.isMyMicMuted,
                isSpeaking = false
            )
            updatedSpeakers.add(mySpeaker)
            soundEngine.playSoundEffect(SoundEffectType.MIC_CLICK)
            _activeRoomState.value = currentState.copy(
                speakers = updatedSpeakers,
                mySeatIndex = seatIndex
            )
        }
    }

    fun leaveSpeakerSeat() {
        val currentState = _activeRoomState.value ?: return
        val mySeat = currentState.mySeatIndex ?: return
        val updatedSpeakers = currentState.speakers.filterNot { it.seatIndex == mySeat }
        _activeRoomState.value = currentState.copy(
            speakers = updatedSpeakers,
            mySeatIndex = null
        )
    }

    fun toggleMyMic() {
        val currentState = _activeRoomState.value ?: return
        val newMute = !currentState.isMyMicMuted
        val mySeat = currentState.mySeatIndex

        val updatedSpeakers = if (mySeat != null) {
            currentState.speakers.map {
                if (it.seatIndex == mySeat) it.copy(isMuted = newMute) else it
            }
        } else currentState.speakers

        soundEngine.playSoundEffect(SoundEffectType.MIC_CLICK)
        _activeRoomState.value = currentState.copy(
            isMyMicMuted = newMute,
            speakers = updatedSpeakers
        )
    }

    fun sendRoomComment(text: String) {
        if (text.isBlank()) return
        val currentState = _activeRoomState.value ?: return
        val profile = userProfile.value ?: UserProfileEntity()

        val newComment = LiveRoomComment(
            senderName = profile.name,
            text = text,
            badge = profile.badge
        )

        _activeRoomState.value = currentState.copy(
            comments = currentState.comments + newComment
        )
    }

    fun sendFloatingReaction(emoji: String) {
        val currentState = _activeRoomState.value ?: return
        val newReaction = FloatingEmoji(emoji = emoji)
        _activeRoomState.value = currentState.copy(
            floatingEmojis = (currentState.floatingEmojis + newReaction).takeLast(15)
        )
        if (emoji == "❤️" || emoji == "💖") {
            soundEngine.playSoundEffect(SoundEffectType.HEART_BEAT)
        } else {
            soundEngine.playSoundEffect(SoundEffectType.PARTY_HORN)
        }
    }

    fun sendGift(gift: GiftItem) {
        val currentState = _activeRoomState.value ?: return
        val profile = userProfile.value ?: return

        if (profile.coins >= gift.coinPrice) {
            viewModelScope.launch {
                repository.updateUserProfile(profile.copy(coins = profile.coins - gift.coinPrice))
            }
            soundEngine.playSoundEffect(SoundEffectType.GIFT_MAGIC)
            _activeRoomState.value = currentState.copy(
                activeGiftBanner = gift,
                activeGiftSender = profile.name
            )

            viewModelScope.launch {
                delay(3000)
                _activeRoomState.value = _activeRoomState.value?.copy(activeGiftBanner = null)
            }
        }
    }

    fun claimDailyBonusCoins() {
        val profile = userProfile.value ?: return
        viewModelScope.launch {
            repository.updateUserProfile(profile.copy(coins = profile.coins + 250))
            soundEngine.playSoundEffect(SoundEffectType.FANFARE)
        }
    }

    fun createNewVoiceRoom(title: String, category: String, language: String) {
        val profile = userProfile.value ?: UserProfileEntity()
        val newRoom = VoiceRoomEntity(
            id = "room_${System.currentTimeMillis()}",
            title = title,
            description = "લાઈવ ગુજરાતી લવ ચેટ અને મસ્તી",
            hostName = profile.name,
            hostAvatar = profile.avatarEmoji,
            hostBadge = "👑 Host VIP",
            category = category,
            language = language,
            activeSpeakerCount = 1,
            listenersCount = 1,
            bannerGradientIndex = Random.nextInt(6)
        )
        viewModelScope.launch {
            repository.createVoiceRoom(newRoom)
            joinVoiceRoom(newRoom)
        }
    }

    fun getMessagesForGroup(groupId: String) = repository.getMessagesForGroup(groupId)

    fun sendGroupTextMessage(groupId: String, text: String) {
        if (text.isBlank()) return
        val profile = userProfile.value ?: UserProfileEntity()
        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

        val message = ChatMessageEntity(
            groupId = groupId,
            senderName = profile.name,
            senderAvatar = profile.avatarEmoji,
            isMe = true,
            text = text,
            timestamp = timeStr
        )
        viewModelScope.launch {
            repository.sendMessage(message)
        }
    }

    fun sendGroupVoiceNote(groupId: String, filePath: String, durationSec: Int) {
        val profile = userProfile.value ?: UserProfileEntity()
        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

        val message = ChatMessageEntity(
            groupId = groupId,
            senderName = profile.name,
            senderAvatar = profile.avatarEmoji,
            isMe = true,
            audioPath = filePath,
            audioDurationSeconds = durationSec,
            timestamp = timeStr
        )
        viewModelScope.launch {
            repository.sendMessage(message)
        }
    }

    fun toggleLikePost(post: SocialPostEntity) {
        viewModelScope.launch {
            repository.toggleLikePost(post)
        }
    }

    fun sharePost(post: SocialPostEntity) {
        viewModelScope.launch {
            repository.incrementShareCount(post)
        }
    }

    fun createSocialPost(text: String, tag: String, audioPath: String? = null, audioTitle: String? = null, duration: Int = 0) {
        val profile = userProfile.value ?: UserProfileEntity()
        val newPost = SocialPostEntity(
            id = "post_${System.currentTimeMillis()}",
            authorName = profile.name,
            authorHandle = "@${profile.name.lowercase().replace(" ", "_")}",
            authorAvatar = profile.avatarEmoji,
            authorBadge = "💖 VIP",
            contentText = text,
            audioSnippetPath = audioPath,
            audioTitle = audioTitle,
            audioDurationSeconds = duration,
            categoryTag = tag,
            likesCount = 1,
            isLiked = true,
            commentsCount = 0,
            sharesCount = 0,
            timeAgo = "હમણાં",
            gradientIndex = Random.nextInt(3)
        )
        viewModelScope.launch {
            repository.createSocialPost(newPost)
        }
    }

    fun updateLanguage(lang: String) {
        val profile = userProfile.value ?: return
        viewModelScope.launch {
            repository.updateUserProfile(profile.copy(selectedLanguage = lang))
        }
    }

    private fun startRoomSimulation() {
        roomSimulationJob?.cancel()
        roomSimulationJob = viewModelScope.launch {
            val randomComments = listOf(
                "Super voice! 💖",
                "વાહ વાહ! શું ગઝલ છે 👏",
                "કાઠિયાવાડી પાવર 🔥",
                "લવલી રૂમ! બધા લાઈક કરો 🌟",
                "હાર્દિક ભાઈ તમે પણ કંઈક બોલો 🎙️",
                "ચા પીવા આવો બધા ☕",
                "Awesome session! 🎉"
            )

            while (isActive && _activeRoomState.value != null) {
                delay(2000)
                val current = _activeRoomState.value ?: break

                // Randomly toggle speaker waveform levels & talking states
                val updatedSpeakers = current.speakers.map { speaker ->
                    if (!speaker.isMuted) {
                        val speaking = Random.nextBoolean()
                        val level = if (speaking) Random.nextFloat() * 0.8f + 0.2f else 0f
                        speaker.copy(isSpeaking = speaking, audioLevel = level)
                    } else {
                        speaker.copy(isSpeaking = false, audioLevel = 0f)
                    }
                }

                // Occasionally add a live simulated comment
                val updatedComments = if (Random.nextInt(4) == 0) {
                    val randomSender = current.audience.randomOrNull()?.name ?: "મિત્ર"
                    val comment = LiveRoomComment(
                        senderName = randomSender,
                        text = randomComments.random()
                    )
                    (current.comments + comment).takeLast(25)
                } else current.comments

                // Occasionally float an emoji
                val updatedEmojis = if (Random.nextInt(3) == 0) {
                    val emojis = listOf("❤️", "💖", "🔥", "👏", "🌹", "✨")
                    val newEmoji = FloatingEmoji(emoji = emojis.random())
                    (current.floatingEmojis + newEmoji).takeLast(15)
                } else current.floatingEmojis

                _activeRoomState.value = current.copy(
                    speakers = updatedSpeakers,
                    comments = updatedComments,
                    floatingEmojis = updatedEmojis
                )
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundEngine.release()
        audioRecorderPlayer.release()
    }
}
