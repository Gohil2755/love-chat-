package com.example.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Context.MODE_PRIVATE
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import java.util.concurrent.TimeUnit

@Composable
fun LoginGate(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("love_chat_session", MODE_PRIVATE) }
    var loggedIn by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser != null || prefs.getBoolean("logged_in", false)) }
    var profileDone by remember { mutableStateOf(prefs.getBoolean("profile_done", false)) }

    if (loggedIn && profileDone) {
        content()
    } else {
        PhoneLoginScreen(
            showProfile = loggedIn && !profileDone,
            onLoggedIn = {
                loggedIn = true
            },
            onProfileSaved = { name, username, isPrivate ->
                prefs.edit()
                    .putBoolean("logged_in", true)
                    .putBoolean("profile_done", true)
                    .putString("name", name)
                    .putString("username", username)
                    .putBoolean("private", isPrivate)
                    .apply()
                profileDone = true
            }
        )
    }
}

@Composable
private fun PhoneLoginScreen(
    showProfile: Boolean,
    onLoggedIn: () -> Unit,
    onProfileSaved: (String, String, Boolean) -> Unit
) {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var codeSent by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var isPrivate by remember { mutableStateOf(false) }

    fun sendOtp() {
        error = null
        if (phone.length != 10) {
            error = "10 અંકનો મોબાઇલ નંબર નાખો"
            return
        }
        val activity = context as? Activity ?: return
        loading = true
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber("+91$phone")
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    auth.signInWithCredential(credential).addOnCompleteListener {
                        loading = false
                        if (it.isSuccessful) onLoggedIn()
                        else error = it.exception?.localizedMessage ?: "Login નિષ્ફળ"
                    }
                }
                override fun onVerificationFailed(e: FirebaseException) {
                    loading = false
                    error = e.localizedMessage ?: "OTP મોકલી શકાયો નથી"
                }
                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    verificationId = id
                    codeSent = true
                    loading = false
                }
            }).build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    fun verifyOtp() {
        val id = verificationId ?: return
        if (otp.length != 6) {
            error = "6 અંકનો OTP નાખો"
            return
        }
        loading = true
        auth.signInWithCredential(PhoneAuthProvider.getCredential(id, otp))
            .addOnCompleteListener {
                loading = false
                if (it.isSuccessful) onLoggedIn()
                else error = it.exception?.localizedMessage ?: "OTP ખોટો છે"
            }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        if (showProfile) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("❤️ Love Chat", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(8.dp))
                Text("તમારું Profile બનાવો")
                Spacer(Modifier.height(20.dp))
                OutlinedTextField(name, { name = it }, label = { Text("તમારું નામ") }, singleLine = true)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(username, { username = it }, label = { Text("Username") }, singleLine = true)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPrivate, onCheckedChange = { isPrivate = it })
                    Text(if (isPrivate) "Private Account" else "Public Account")
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        if (name.isNotBlank() && username.isNotBlank()) onProfileSaved(name, username, isPrivate)
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Profile Create કરો") }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("❤️", style = MaterialTheme.typography.displaySmall)
                Text("Love Chat", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Text("Mobile Number થી Login", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(24.dp))
                if (!codeSent) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it.filter(Char::isDigit).take(10) },
                        label = { Text("Mobile Number") },
                        prefix = { Text("+91 ") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(sendOtp, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                        Text(if (loading) "OTP મોકલી રહ્યા છીએ..." else "Send OTP")
                    }
                } else {
                    OutlinedTextField(
                        value = otp,
                        onValueChange = { otp = it.filter(Char::isDigit).take(6) },
                        label = { Text("6 Digit OTP") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(verifyOtp, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(16.dp)) {
                        Text(if (loading) "Verify..." else "Verify OTP")
                    }
                    TextButton(onClick = { codeSent = false; otp = "" }) { Text("નંબર બદલો") }
                }
                error?.let {
                    Spacer(Modifier.height(12.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}
