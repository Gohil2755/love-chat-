package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = BolPurple,
    onPrimary = Color.White,
    primaryContainer = BolPurpleDark,
    onPrimaryContainer = Color.White,
    secondary = BolCoral,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF4A1226),
    onSecondaryContainer = Color(0xFFFFD9E2),
    tertiary = BolGold,
    onTertiary = Color(0xFF3E2D00),
    background = BolDarkBg,
    onBackground = Color(0xFFE6E1E5),
    surface = BolDarkSurface,
    onSurface = Color(0xFFE6E1E5),
    surfaceVariant = BolDarkSurfaceElevated,
    onSurfaceVariant = Color(0xFFCAC4D0),
    outline = Color(0xFF49454F)
)

private val LightColorScheme = lightColorScheme(
    primary = BolPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFEDE9FE),
    onPrimaryContainer = BolPurpleDark,
    secondary = BolCoral,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE4E8),
    onSecondaryContainer = Color(0xFF90002A),
    tertiary = BolAmber,
    onTertiary = Color.Black,
    background = BolLightBg,
    onBackground = Color(0xFF1E293B),
    surface = BolLightSurface,
    onSurface = Color(0xFF1E293B),
    surfaceVariant = BolLightCard,
    onSurfaceVariant = Color(0xFF64748B),
    outline = Color(0xFFCBD5E1)
)

@Composable
fun BolChatTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    BolChatTheme(darkTheme = darkTheme, content = content)
}
