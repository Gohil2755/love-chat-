package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.ChatMessageEntity
import com.example.ui.VoiceViewModel
import com.example.ui.components.WaveformVisualizer
import com.example.ui.theme.BolCoral
import com.example.ui.theme.BolEmerald
import com.example.ui.theme.BolPurple

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    groupId: String,
    viewModel: VoiceViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.getMessagesForGroup(groupId).collectAsStateWithLifecycle(initialValue = emptyList())
    val groupChats by viewModel.groupChats.collectAsStateWithLifecycle()
    val group = groupChats.find { it.id == groupId }

    var textInput by remember { mutableStateOf("") }
    val isRecording by viewModel.audioRecorderPlayer.isRecording.collectAsStateWithLifecycle()
    val recordingDuration by viewModel.audioRecorderPlayer.recordingDurationSeconds.collectAsStateWithLifecycle()
    val recordingAmplitude by viewModel.audioRecorderPlayer.currentAmplitude.collectAsStateWithLifecycle()

    val isPlaying by viewModel.audioRecorderPlayer.isPlaying.collectAsStateWithLifecycle()
    val activePath by viewModel.audioRecorderPlayer.activeAudioPath.collectAsStateWithLifecycle()
    val playbackProgress by viewModel.audioRecorderPlayer.playbackProgress.collectAsStateWithLifecycle()
    val playbackSpeed by viewModel.audioRecorderPlayer.playbackSpeed.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(BolPurple.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = group?.avatarEmoji ?: "💬", fontSize = 22.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = group?.name ?: "ગ્રુપ ચેટ",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "${group?.memberCount ?: 500} સભ્યો • 🔊 વોઇસ સક્ષમ",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("btn_chat_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    // Recording Indicator Banner
                    AnimatedVisibility(visible = isRecording) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BolCoral.copy(alpha = 0.15f))
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(CircleShape)
                                        .background(BolCoral)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "વોઇસ રેકોર્ડ થાય છે... ${recordingDuration}s",
                                    color = BolCoral,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            WaveformVisualizer(
                                barCount = 10,
                                isLive = true,
                                amplitude = recordingAmplitude,
                                primaryColor = BolCoral,
                                secondaryColor = BolPurple,
                                height = 18.dp,
                                modifier = Modifier.width(60.dp)
                            )
                            IconButton(onClick = { viewModel.audioRecorderPlayer.cancelRecording() }) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = BolCoral)
                            }
                        }
                    }

                    // Input Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            placeholder = { Text("સંદેશ લખો...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_text_input"),
                            shape = RoundedCornerShape(24.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BolPurple,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline
                            )
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        if (textInput.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    viewModel.sendGroupTextMessage(groupId, textInput)
                                    textInput = ""
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(BolPurple)
                                    .testTag("btn_send_text_message")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = Color.White
                                )
                            }
                        } else {
                            // Mic Button for Voice Note
                            IconButton(
                                onClick = {
                                    if (isRecording) {
                                        val recordedFile = viewModel.audioRecorderPlayer.stopRecording()
                                        if (recordedFile != null) {
                                            viewModel.sendGroupVoiceNote(
                                                groupId,
                                                recordedFile.absolutePath,
                                                recordingDuration.coerceAtLeast(1)
                                            )
                                        }
                                    } else {
                                        viewModel.audioRecorderPlayer.startRecording()
                                    }
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(if (isRecording) BolCoral else BolPurple)
                                    .testTag("btn_record_voice_note")
                            ) {
                                Icon(
                                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
                                    contentDescription = "Record Voice Note",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 14.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.messageId }) { msg ->
                ChatMessageBubble(
                    message = msg,
                    isPlaying = isPlaying && activePath == msg.audioPath,
                    playbackProgress = if (activePath == msg.audioPath) playbackProgress else 0f,
                    playbackSpeed = playbackSpeed,
                    onPlayAudio = { path -> viewModel.audioRecorderPlayer.playAudio(path) },
                    onStopAudio = { viewModel.audioRecorderPlayer.stopPlayback() },
                    onSpeedCycle = { viewModel.audioRecorderPlayer.cyclePlaybackSpeed() }
                )
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: ChatMessageEntity,
    isPlaying: Boolean,
    playbackProgress: Float,
    playbackSpeed: Float,
    onPlayAudio: (String) -> Unit,
    onStopAudio: () -> Unit,
    onSpeedCycle: () -> Unit
) {
    val isMe = message.isMe
    val alignment = if (isMe) Alignment.End else Alignment.Start

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = alignment
    ) {
        if (!isMe) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = message.senderAvatar, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = message.senderName,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
        }

        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (isMe) 16.dp else 4.dp,
                        bottomEnd = if (isMe) 4.dp else 16.dp
                    )
                )
                .background(
                    if (isMe) BolPurple else MaterialTheme.colorScheme.surfaceVariant
                )
                .padding(12.dp)
        ) {
            if (message.audioPath != null) {
                // Voice Note Player UI
                Column(modifier = Modifier.width(220.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = {
                                if (isPlaying) onStopAudio() else onPlayAudio(message.audioPath)
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isMe) Color.White.copy(alpha = 0.25f) else BolPurple)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color.White
                            )
                        }

                        WaveformVisualizer(
                            barCount = 14,
                            isLive = isPlaying,
                            amplitude = if (isPlaying) 0.8f else 0.3f,
                            primaryColor = if (isMe) Color.White else BolPurple,
                            secondaryColor = if (isMe) BolCoral else BolCoral,
                            height = 24.dp,
                            modifier = Modifier.width(90.dp)
                        )

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isMe) Color.White.copy(alpha = 0.2f) else BolPurple.copy(alpha = 0.15f))
                                .clickable { onSpeedCycle() }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "${playbackSpeed}x",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isMe) Color.White else BolPurple
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { playbackProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = if (isMe) Color.White else BolPurple,
                        trackColor = if (isMe) Color.White.copy(alpha = 0.3f) else Color.LightGray
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "🎙️ વોઇસ નોટ",
                            fontSize = 10.sp,
                            color = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${message.audioDurationSeconds}s • ${message.timestamp}",
                            fontSize = 10.sp,
                            color = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                // Regular Text Message
                Column {
                    Text(
                        text = message.text ?: "",
                        color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = message.timestamp,
                        color = if (isMe) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }
    }
}
