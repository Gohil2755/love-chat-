package com.example.data

import com.example.data.local.ChatMessageEntity
import com.example.data.local.GroupChatEntity
import com.example.data.local.SocialPostEntity
import com.example.data.local.UserProfileEntity
import com.example.data.local.VoiceDao
import com.example.data.local.VoiceRoomEntity
import com.example.data.sync.FirestoreGroupChatSyncRepository
import com.example.data.sync.GroupChatSyncRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.Flow

class VoiceRepository(
    private val dao: VoiceDao,
    val chatSyncRepository: GroupChatSyncRepository = FirestoreGroupChatSyncRepository(dao)
) {

    fun getAllVoiceRooms(): Flow<List<VoiceRoomEntity>> = dao.getAllVoiceRooms()

    suspend fun getVoiceRoomById(id: String): VoiceRoomEntity? = dao.getVoiceRoomById(id)

    suspend fun createVoiceRoom(room: VoiceRoomEntity) = dao.insertVoiceRoom(room)

    fun getAllGroupChats(): Flow<List<GroupChatEntity>> = dao.getAllGroupChats()

    suspend fun getGroupChatById(id: String): GroupChatEntity? = dao.getGroupChatById(id)

    fun getMessagesForGroup(groupId: String): Flow<List<ChatMessageEntity>> =
        dao.getMessagesForGroup(groupId)

    suspend fun sendMessage(message: ChatMessageEntity): Long {
        val result = chatSyncRepository.sendMessageAndSync(message)
        return result.getOrDefault(0L)
    }

    fun getAllSocialPosts(): Flow<List<SocialPostEntity>> = dao.getAllSocialPosts()

    suspend fun createSocialPost(post: SocialPostEntity) = dao.insertSocialPost(post)

    suspend fun toggleLikePost(post: SocialPostEntity) {
        val isNowLiked = !post.isLiked
        val newLikesCount = if (isNowLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
        dao.updateSocialPost(post.copy(isLiked = isNowLiked, likesCount = newLikesCount))
    }

    suspend fun incrementShareCount(post: SocialPostEntity) {
        dao.updateSocialPost(post.copy(sharesCount = post.sharesCount + 1))
    }

    fun getUserProfile(): Flow<UserProfileEntity?> = dao.getUserProfile()

    suspend fun updateUserProfile(profile: UserProfileEntity) = dao.updateUserProfile(profile)

    suspend fun deductCoins(amount: Int): Boolean {
        // Will be managed through ViewModel StateFlow & DAO
        return true
    }
}
