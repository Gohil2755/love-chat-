package com.example.data.local

object SampleDataProvider {

    fun getInitialVoiceRooms(): List<VoiceRoomEntity> = listOf(
        VoiceRoomEntity(
            id = "room_love_1",
            title = "દિલની વાતો અને રોમેન્ટિક શાયરી ❤️",
            description = "મીઠી મીઠી વાતો, લવ શાયરી અને સુરીલા ગીતોની મોજ",
            hostName = "રોનક & પ્રિયંકા",
            hostAvatar = "💑",
            hostBadge = "👑 Couple VIP",
            category = "Love & Romance",
            language = "ગુજરાતી",
            activeSpeakerCount = 6,
            listenersCount = 284,
            bannerGradientIndex = 0
        ),
        VoiceRoomEntity(
            id = "room_masti_2",
            title = "સુરતી મસ્તી, ગપ્પા અને હાસ્ય દરબાર 😂",
            description = "દેશી કાઠિયાવાડી અને સુરતી મજાક-મસ્તી",
            hostName = "કલ્પેશ ભાઈ પટેલ",
            hostAvatar = "🤠",
            hostBadge = "🎙️ Top Host",
            category = "Gujarati Masti",
            language = "ગુજરાતી",
            activeSpeakerCount = 8,
            listenersCount = 412,
            bannerGradientIndex = 1
        ),
        VoiceRoomEntity(
            id = "room_music_3",
            title = "અંતાક્ષરી અને ગરબા નાઇટ 🎶💃",
            description = "લાઈવ સિંગિંગ અને બોલીવુડ-ગુજરાતી ગીતોની રમઝટ",
            hostName = "ધ્વનિ & મિત્રો",
            hostAvatar = "🎤",
            hostBadge = "⭐ Singer",
            category = "Music & Antakshari",
            language = "ગુજરાતી",
            activeSpeakerCount = 7,
            listenersCount = 350,
            bannerGradientIndex = 2
        ),
        VoiceRoomEntity(
            id = "room_shayari_4",
            title = "દર્દ-એ-દિલ શાયરી ક્લબ 🥀💔",
            description = "ગઝલ, શાયરી અને કવિતા રસિકોનો લાઈવ અડ્ડો",
            hostName = "શાયર સાહિલ",
            hostAvatar = "✍️",
            hostBadge = "📜 Poet VIP",
            category = "Shayari & Ghazal",
            language = "ગુજરાતી",
            activeSpeakerCount = 4,
            listenersCount = 189,
            bannerGradientIndex = 3
        ),
        VoiceRoomEntity(
            id = "room_bhakti_5",
            title = "પ્રભાતિયા અને ભક્તિ સત્સંગ 🕉️🙏",
            description = "સવારના ભજનો અને આધ્યાત્મિક વાતો",
            hostName = "પૂજાબેન શાહ",
            hostAvatar = "🌸",
            hostBadge = "🕊️ Satsangi",
            category = "Bhakti",
            language = "ગુજરાતી",
            activeSpeakerCount = 3,
            listenersCount = 230,
            bannerGradientIndex = 4
        ),
        VoiceRoomEntity(
            id = "room_youth_6",
            title = "Night Owls Late Night Chat 🌙✨",
            description = "મોડી રાતની ગોસિપ અને ફ્રેન્ડશીપ ચર્ચા",
            hostName = "યશ & તાન્યા",
            hostAvatar = "🎧",
            hostBadge = "🔥 Trending",
            category = "Romance",
            language = "ગુજરાતી / Hinglish",
            activeSpeakerCount = 5,
            listenersCount = 310,
            bannerGradientIndex = 5
        )
    )

    fun getInitialGroupChats(): List<GroupChatEntity> = listOf(
        GroupChatEntity(
            id = "group_love_birds",
            name = "❤️ લવ બર્ડ્સ કલબ (Love Birds)",
            description = "રોમેન્ટિક વાતો, કવિતાઓ અને વોઇસ ચેટ",
            avatarEmoji = "💖",
            memberCount = 1420,
            unreadCount = 2,
            lastMessageText = "સાંજની ચા અને તારી યાદ... ☕❤️",
            lastMessageSender = "પ્રિયા",
            lastMessageTime = "10:15 AM",
            isLiveVoiceActive = true,
            category = "Love"
        ),
        GroupChatEntity(
            id = "group_kathiyawadi_adda",
            name = "🦁 રંગીલું કાઠિયાવાડ & સુરત",
            description = "ખમતીધર મિત્રોનું લાઈવ ગ્રુપ",
            avatarEmoji = "🦁",
            memberCount = 3850,
            unreadCount = 0,
            lastMessageText = "કાલે કોણ કોણ ગરબામાં આવે છે?",
            lastMessageSender = "હાર્દિક",
            lastMessageTime = "09:40 AM",
            isLiveVoiceActive = false,
            category = "Masti"
        ),
        GroupChatEntity(
            id = "group_shayari_dilse",
            name = "📜 શાયરી દિલ સે (Shayari Dil Se)",
            description = "શાયરી, ગઝલ અને સ્ટેટસ નો ખજાનો",
            avatarEmoji = "🥀",
            memberCount = 2100,
            unreadCount = 5,
            lastMessageText = "🎤 [વોઇસ નોટ 0:18] - નવી ગઝલ",
            lastMessageSender = "રાજેશ",
            lastMessageTime = "ગઈકાલે",
            isLiveVoiceActive = true,
            category = "Shayari"
        ),
        GroupChatEntity(
            id = "group_music_lovers",
            name = "🎶 અવાજની દુનિયા (Music Lovers)",
            description = "સિંગિંગ સ્પર્ધા અને વોઇસ રેકોર્ડિંગ શેરિંગ",
            avatarEmoji = "🎸",
            memberCount = 980,
            unreadCount = 1,
            lastMessageText = "તમારો અવાજ ખરેખર સરસ છે!",
            lastMessageSender = "પૂજા",
            lastMessageTime = "08:12 AM",
            isLiveVoiceActive = false,
            category = "Music"
        )
    )

    fun getInitialMessages(groupId: String): List<ChatMessageEntity> = when (groupId) {
        "group_love_birds" -> listOf(
            ChatMessageEntity(
                groupId = groupId,
                senderName = "પ્રિયા",
                senderAvatar = "🌸",
                isMe = false,
                text = "ગુડ મોર્નિંગ બધાને! આજનો દિવસ તમારા માટે ખુશીઓ લાવે ✨",
                timestamp = "09:00 AM",
                reactions = "❤️ 12, 🌸 8"
            ),
            ChatMessageEntity(
                groupId = groupId,
                senderName = "આરવ",
                senderAvatar = "🎸",
                isMe = false,
                text = "તારા વિના આ દિલ ક્યાંય લાગતું નથી... 🎶",
                timestamp = "09:30 AM",
                reactions = "💖 15"
            ),
            ChatMessageEntity(
                groupId = groupId,
                senderName = "પ્રિયા",
                senderAvatar = "🌸",
                isMe = false,
                text = "સાંજની ચા અને તારી યાદ... ☕❤️",
                timestamp = "10:15 AM",
                reactions = "😍 9"
            )
        )
        else -> listOf(
            ChatMessageEntity(
                groupId = groupId,
                senderName = "કલ્પેશ",
                senderAvatar = "🤠",
                isMe = false,
                text = "જય શ્રી કૃષ્ણ મિત્રો! બધા મજામાં ને?",
                timestamp = "08:30 AM",
                reactions = "🙏 18"
            ),
            ChatMessageEntity(
                groupId = groupId,
                senderName = "હાર્દિક",
                senderAvatar = "🦁",
                isMe = false,
                text = "હા ભાઈ, એકદમ મોજે મોજ!",
                timestamp = "08:45 AM",
                reactions = "🔥 10"
            )
        )
    }

    fun getInitialSocialPosts(): List<SocialPostEntity> = listOf(
        SocialPostEntity(
            id = "post_1",
            authorName = "પ્રિયા શાહ",
            authorHandle = "@priya_surat",
            authorAvatar = "🌸",
            authorBadge = "🎙️ Top Creator",
            contentText = "તારી આંખોમાં જે પ્રેમ દેખાય છે, એ આખી દુનિયામાં ક્યાંય નથી મળતો... સાંભળો આ મીઠી શાયરી ❤️🌹",
            audioSnippetPath = "sample_audio_1",
            audioTitle = "લવ શાયરી - દિલની ધડકન",
            audioDurationSeconds = 24,
            categoryTag = "લવ સ્ટેટસ",
            likesCount = 842,
            isLiked = false,
            commentsCount = 94,
            sharesCount = 312,
            timeAgo = "10 મિનિટ પહેલા",
            gradientIndex = 0
        ),
        SocialPostEntity(
            id = "post_2",
            authorName = "શાયર કબીર",
            authorHandle = "@kabir_shayari",
            authorAvatar = "✍️",
            authorBadge = "📜 Verified",
            contentText = "સંબંધો સાચા હોય તો શબ્દોની જરૂર નથી પડતી, એક અવાજથી જ દિલના હાલ સમજાઈ જાય છે. ✨",
            audioSnippetPath = "sample_audio_2",
            audioTitle = "ગઝલ - અહેસાસ",
            audioDurationSeconds = 32,
            categoryTag = "શાયરી",
            likesCount = 1250,
            isLiked = true,
            commentsCount = 160,
            sharesCount = 540,
            timeAgo = "1 કલાક પહેલા",
            gradientIndex = 1
        ),
        SocialPostEntity(
            id = "post_3",
            authorName = "ગુજરાતી ગીત સંગમ",
            authorHandle = "@garba_beats",
            authorAvatar = "💃",
            authorBadge = "🎵 Music Hub",
            contentText = "નવરાત્રી સ્પેશિયલ નવું ગરબા ફ્યુઝન ટ્રેક! હેડો બધા ગરબે ઘૂમવા 🥁🎧",
            audioSnippetPath = "sample_audio_3",
            audioTitle = "નવરાત્રી ગરબા રીમિક્સ 2026",
            audioDurationSeconds = 45,
            categoryTag = "ગરબા",
            likesCount = 2890,
            isLiked = false,
            commentsCount = 340,
            sharesCount = 1100,
            timeAgo = "3 કલાક પહેલા",
            gradientIndex = 2
        )
    )
}
