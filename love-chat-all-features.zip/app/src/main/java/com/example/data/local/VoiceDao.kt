package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceDao {

    // Voice Rooms
    @Query("SELECT * FROM voice_rooms ORDER BY listenersCount DESC")
    fun getAllVoiceRooms(): Flow<List<VoiceRoomEntity>>

    @Query("SELECT * FROM voice_rooms WHERE id = :roomId LIMIT 1")
    suspend fun getVoiceRoomById(roomId: String): VoiceRoomEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVoiceRooms(rooms: List<VoiceRoomEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVoiceRoom(room: VoiceRoomEntity)

    @Update
    suspend fun updateVoiceRoom(room: VoiceRoomEntity)

    // Group Chats
    @Query("SELECT * FROM group_chats ORDER BY id ASC")
    fun getAllGroupChats(): Flow<List<GroupChatEntity>>

    @Query("SELECT * FROM group_chats WHERE id = :groupId LIMIT 1")
    suspend fun getGroupChatById(groupId: String): GroupChatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGroupChats(chats: List<GroupChatEntity>)

    @Update
    suspend fun updateGroupChat(chat: GroupChatEntity)

    // Chat Messages
    @Query("SELECT * FROM chat_messages WHERE groupId = :groupId ORDER BY createdAt ASC")
    fun getMessagesForGroup(groupId: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<ChatMessageEntity>)

    // Social Feed Posts
    @Query("SELECT * FROM social_posts ORDER BY createdAt DESC")
    fun getAllSocialPosts(): Flow<List<SocialPostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialPosts(posts: List<SocialPostEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSocialPost(post: SocialPostEntity)

    @Update
    suspend fun updateSocialPost(post: SocialPostEntity)

    // User Profile
    @Query("SELECT * FROM user_profile WHERE userId = :userId LIMIT 1")
    fun getUserProfile(userId: String = "me_user_1"): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserProfile(profile: UserProfileEntity)

    @Update
    suspend fun updateUserProfile(profile: UserProfileEntity)
}
