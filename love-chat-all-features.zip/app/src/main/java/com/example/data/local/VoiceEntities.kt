package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "voice_rooms")
data class VoiceRoomEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val hostName: String,
    val hostAvatar: String,
    val hostBadge: String = "👑 Host",
    val category: String, // Romance, Gujarati Masti, Shayari, Music, Bhakti, Comedy
    val language: String, // ગુજરાતી, हिन्दी, English
    val activeSpeakerCount: Int = 1,
    val listenersCount: Int = 120,
    val isLive: Boolean = true,
    val roomTags: String = "ઓડિયો,મસ્તી,ચેટ",
    val bannerGradientIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "group_chats")
data class GroupChatEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val avatarEmoji: String,
    val memberCount: Int,
    val unreadCount: Int = 0,
    val lastMessageText: String = "",
    val lastMessageSender: String = "",
    val lastMessageTime: String = "હમણાં",
    val isLiveVoiceActive: Boolean = false,
    val category: String = "Gujarati"
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val messageId: Long = 0,
    val groupId: String,
    val senderName: String,
    val senderAvatar: String,
    val isMe: Boolean,
    val text: String? = null,
    val audioPath: String? = null,
    val audioDurationSeconds: Int = 0,
    val timestamp: String = "હમણાં",
    val reactions: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "social_posts")
data class SocialPostEntity(
    @PrimaryKey val id: String,
    val authorName: String,
    val authorHandle: String,
    val authorAvatar: String,
    val authorBadge: String = "🎙️ Creator",
    val contentText: String,
    val audioSnippetPath: String? = null,
    val audioTitle: String? = null,
    val audioDurationSeconds: Int = 0,
    val categoryTag: String, // શાયરી, લવ સ્ટેટસ, ગરબા, સુવિચાર, મસ્તી
    val likesCount: Int = 0,
    val isLiked: Boolean = false,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val timeAgo: String = "હમણાં",
    val gradientIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val userId: String = "me_user_1",
    val name: String = "ગુજરાતી લવર",
    val bio: String = "❤️ પ્રેમ અને સુરીલા અવાજની દુનિયા | Love Chat VIP",
    val avatarEmoji: String = "💖",
    val badge: String = "🌟 Star Member",
    val coins: Int = 1250,
    val diamonds: Int = 85,
    val selectedLanguage: String = "ગુજરાતી",
    val followersCount: Int = 340,
    val followingCount: Int = 128
)
