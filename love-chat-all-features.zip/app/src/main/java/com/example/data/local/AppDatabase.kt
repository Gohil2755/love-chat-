package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        VoiceRoomEntity::class,
        GroupChatEntity::class,
        ChatMessageEntity::class,
        SocialPostEntity::class,
        UserProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun voiceDao(): VoiceDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "love_chat_db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val dao = getInstance(context).voiceDao()
                            dao.insertVoiceRooms(SampleDataProvider.getInitialVoiceRooms())
                            dao.insertGroupChats(SampleDataProvider.getInitialGroupChats())
                            dao.insertMessages(SampleDataProvider.getInitialMessages("group_love_birds"))
                            dao.insertMessages(SampleDataProvider.getInitialMessages("group_kathiyawadi_adda"))
                            dao.insertSocialPosts(SampleDataProvider.getInitialSocialPosts())
                            dao.insertUserProfile(UserProfileEntity())
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
